
package com.sena.Inventario.Service.Implement;

import com.sena.Inventario.Models_Clases.Venta;
import com.sena.Inventario.Dao.VentaDao;
import com.sena.Inventario.Service.VentaService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;
        
@Service 
public class VentaImplement implements VentaService{
    
    @Autowired
    private VentaDao ventaDao;

    @Override
    @Transactional(readOnly=false)
    public Venta save(Venta venta) {
        return ventaDao.save(venta);         
    } 

    @Override
    @Transactional(readOnly=false)
    public void delete(Integer id) {
        ventaDao.deleteById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public Venta findById(Integer id) {
        return ventaDao.findById(id).orElse(null);
                
    }

    @Override
    @Transactional(readOnly=true)
    public List<Venta> findByAll() {
        return (List<Venta>) ventaDao.findAll();
    }
}
