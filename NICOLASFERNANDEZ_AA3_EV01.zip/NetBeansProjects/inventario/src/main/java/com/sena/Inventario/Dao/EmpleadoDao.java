
package com.sena.Inventario.Dao;
import com.sena.Inventario.Models_Clases.Empleado;
import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface EmpleadoDao extends CrudRepository<Empleado,Integer> {
    
    @Transactional(readOnly=true)  //True no modifica ningun campo de la bd, solo lectura.
    @Query(value="select * from Empleado where CodEmpleado=:usuario and CodEmpleado=:clave" ,nativeQuery=true)
    public Empleado login(@Param("usuario") Integer usuario, @Param("clave") Integer clave);  
    
    @Transactional(readOnly=true)  //True no modifica ningun campo de la bd, solo lectura.
    @Query(value="select * from Empleado where CodEmpleado=:CodE" ,nativeQuery=true)
    public List<Empleado> consulta_empleado(@Param("CodE") Integer CodE);  
       
}
 