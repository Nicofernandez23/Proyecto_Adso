
package com.sena.Inventario.Dao;
import com.sena.Inventario.Models_Clases.Venta;
import java.util.List;
import javax.print.attribute.standard.DateTimeAtCompleted;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface VentaDao extends CrudRepository<Venta,Integer> {
    
    @Transactional(readOnly=true)  //True no modifica ningun campo de la bd, solo lectura.
    @Query(value="select * from Venta where CodEmpleado=:CodE" ,nativeQuery=true)
    public List<Venta> consulta_venta_empleado(@Param("CodE") Integer CodE);
    
    @Transactional(readOnly=true)  //True no modifica ningun campo de la bd, solo lectura.
    @Query(value="select * from Venta where CodCliente=:CodC" ,nativeQuery=true)
    public List<Venta> consulta_venta_cliente(@Param("CodC") Integer CodC);    
    
    @Transactional(readOnly=true)  //True no modifica ningun campo de la bd, solo lectura.
    @Query(value="select * from Venta where CodVenta=:CodV" ,nativeQuery=true)
    public List<Venta> consulta_venta (@Param("CodV") Integer CodV);
    
    @Transactional(readOnly=false)  //False  modifica los campos de la bd, insert, delete, update.
    @Query(value="update Venta set FechaVenta=:FeV, TotalVenta=:ToV, CodCliente=:CodC" ,nativeQuery=true)
    public void actualizacion_venta (@Param("FeV") DateTimeAtCompleted FeV, @Param("ToV") Integer ToV, @Param("CodC") Integer CodC); 
    
    //Falta el insert
}
