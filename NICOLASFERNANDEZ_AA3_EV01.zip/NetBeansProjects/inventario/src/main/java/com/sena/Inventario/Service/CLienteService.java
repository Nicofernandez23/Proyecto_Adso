
package com.sena.Inventario.Service;
import com.sena.Inventario.Models_Clases.CLiente;
import java.util.List;

public interface CLienteService {
    public CLiente save(CLiente cliente);
    public void delete(Integer id);
    public CLiente findById(Integer id);
    public List<CLiente> findByAll();
    
        
}
