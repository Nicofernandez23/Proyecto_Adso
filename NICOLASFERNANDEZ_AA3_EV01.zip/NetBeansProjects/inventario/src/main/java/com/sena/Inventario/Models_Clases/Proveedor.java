
package com.sena.Inventario.Models_Clases;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

public class Proveedor implements Serializable {
    @Id
    @Column(name="CodProveedor")
    private Integer CodProveedor;
    @Column(name="NombreProveedor")
    private String NombreProveedor;
    @Column(name="DireccionProveedor")
    private String DireccionProveedor;
    @Column(name="TelProveedor")
    private String TelProveedor;
    @Column(name="ProductoProveedor")
    private String ProductoProveedor;
    @ManyToOne
    @JoinColumn (name="CodEmpresa")
    private Empresa CodEmpresa; //Foranea, se debe definir la tabla con la que se relaciona "Empresa" y luego el campo

    public Proveedor() {
    }

    public Proveedor(Integer CodProveedor, String NombreProveedor, String DireccionProveedor, String TelProveedor, String ProductoProveedor, Empresa CodEmpresa) {
        this.CodProveedor = CodProveedor;
        this.NombreProveedor = NombreProveedor;
        this.DireccionProveedor = DireccionProveedor;
        this.TelProveedor = TelProveedor;
        this.ProductoProveedor = ProductoProveedor;
        this.CodEmpresa = CodEmpresa;
    }

    public Integer getCodProveedor() {
        return CodProveedor;
    }

    public void setCodProveedor(Integer CodProveedor) {
        this.CodProveedor = CodProveedor;
    }

    public String getNombreProveedor() {
        return NombreProveedor;
    }

    public void setNombreProveedor(String NombreProveedor) {
        this.NombreProveedor = NombreProveedor;
    }

    public String getDireccionProveedor() {
        return DireccionProveedor;
    }

    public void setDireccionProveedor(String DireccionProveedor) {
        this.DireccionProveedor = DireccionProveedor;
    }

    public String getTelProveedor() {
        return TelProveedor;
    }

    public void setTelProveedor(String TelProveedor) {
        this.TelProveedor = TelProveedor;
    }

    public String getProductoProveedor() {
        return ProductoProveedor;
    }

    public void setProductoProveedor(String ProductoProveedor) {
        this.ProductoProveedor = ProductoProveedor;
    }

    public Empresa getCodEmpresa() {
        return CodEmpresa;
    }

    public void setCodEmpresa(Empresa CodEmpresa) {
        this.CodEmpresa = CodEmpresa;
    }

   
}
