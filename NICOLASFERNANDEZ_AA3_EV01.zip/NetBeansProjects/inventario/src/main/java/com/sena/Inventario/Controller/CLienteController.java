
package com.sena.Inventario.Controller;

import com.sena.Inventario.Models_Clases.CLiente;
import com.sena.Inventario.Service.CLienteService;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/CLiente")
public class CLienteController {
    @Autowired
    private CLienteService clienteservice;
    
    @PostMapping(value="/")
    public ResponseEntity<CLiente> agregar(@RequestBody CLiente cliente){        
        CLiente obj = clienteservice.save(cliente);
        return new ResponseEntity<>(obj, HttpStatus.OK);     
    }

     @DeleteMapping(value="/{id}") 
    public ResponseEntity<CLiente> eliminar(@PathVariable String id){ 
        CLiente obj = clienteservice.findById(Integer.SIZE);
        if(obj!=null) 
            clienteservice.delete(Integer.SIZE);
        else 
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR); 
        return new ResponseEntity<>(obj, HttpStatus.OK); 
    }
 
    @PutMapping(value="/") 
    public ResponseEntity<CLiente> editar(@RequestBody CLiente cliente){ 
        CLiente obj = clienteservice.findById(cliente.getCodCliente());
        if(obj!=null) {
            obj.setNombreCliente(cliente.getNombreCliente());
            obj.setDireccionCliente(cliente.getDireccionCliente());
            obj.setContactoCliente(cliente.getContactoCliente());
            clienteservice.save(obj); 
        } 
        else 
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR); 
        return new ResponseEntity<>(obj, HttpStatus.OK); 
    }

    @GetMapping("/list")
    public List<CLiente> consultarTodo(){
        return clienteservice.findByAll(); 
    }

    @GetMapping("/list/{id}") 
    public CLiente consultaPorId(@PathVariable Integer id){ 
        return clienteservice.findById(Integer.SIZE);
    }
    
}
