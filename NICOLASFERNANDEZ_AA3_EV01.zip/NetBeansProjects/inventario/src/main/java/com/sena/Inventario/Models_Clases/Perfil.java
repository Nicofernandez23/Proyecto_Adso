
package com.sena.Inventario.Models_Clases;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

public class Perfil implements Serializable {
    @Id
    @Column(name="CodPerfil")
    private Integer CodPerfil;
    @Column(name="NombrePerfil")
    private String NombrePerfil;

    public Perfil() {
    }

    public Perfil(Integer CodPerfil, String NombrePerfil) {
        this.CodPerfil = CodPerfil;
        this.NombrePerfil = NombrePerfil;
    }

    public Integer getCodPerfil() {
        return CodPerfil;
    }

    public void setCodPerfil(Integer CodPerfil) {
        this.CodPerfil = CodPerfil;
    }

    public String getNombrePerfil() {
        return NombrePerfil;
    }

    public void setNombrePerfil(String NombrePerfil) {
        this.NombrePerfil = NombrePerfil;
    }
    
    
}
