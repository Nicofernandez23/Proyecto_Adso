
package com.sena.Inventario.Models_Clases;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

public class Detalle_Venta implements Serializable {
    @Id
    @Column(name="CodVenta")
    private Integer CodVenta;
    @ManyToOne
    @JoinColumn (name="CodProducto")
    private Producto CodProducto; //Foranea, se debe definir la tabla con la que se relaciona "Producto" y luego el campo
    @Column(name="CantidadVenta")
    private Double CantidadVenta;

    public Detalle_Venta() {
    }

    public Detalle_Venta(Integer CodVenta, Producto CodProducto, Double CantidadVenta) {
        this.CodVenta = CodVenta;
        this.CodProducto = CodProducto;
        this.CantidadVenta = CantidadVenta;
    }

    public Integer getCodVenta() {
        return CodVenta;
    }

    public void setCodVenta(Integer CodVenta) {
        this.CodVenta = CodVenta;
    }

    public Producto getCodProducto() {
        return CodProducto;
    }

    public void setCodProducto(Producto CodProducto) {
        this.CodProducto = CodProducto;
    }

    public Double getCantidadVenta() {
        return CantidadVenta;
    }

    public void setCantidadVenta(Double CantidadVenta) {
        this.CantidadVenta = CantidadVenta;
    }
    
    
}
