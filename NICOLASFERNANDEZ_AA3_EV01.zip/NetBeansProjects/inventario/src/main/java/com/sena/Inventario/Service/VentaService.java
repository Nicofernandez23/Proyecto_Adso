
package com.sena.Inventario.Service;
import com.sena.Inventario.Models_Clases.Venta;
import java.util.List;

public interface VentaService {
    public Venta save(Venta Venta);
    public void delete(Integer id);
    public Venta findById(Integer id);
    public List<Venta> findByAll();
    

}
