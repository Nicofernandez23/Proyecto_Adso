
package com.sena.Inventario.Service.Implement;

import com.sena.Inventario.Models_Clases.CLiente;
import com.sena.Inventario.Dao.CLienteDao;
import com.sena.Inventario.Service.CLienteService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;
        
@Service        
public class CLienteImplement implements CLienteService {
    
    @Autowired
    private CLienteDao clienteDao;

    @Override
    @Transactional(readOnly=false)
    public CLiente save(CLiente cliente) {
        return clienteDao.save(cliente);         
    } 

    @Override
    @Transactional(readOnly=false)
    public void delete(Integer id) {
        clienteDao.deleteById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public CLiente findById(Integer id) {
        return clienteDao.findById(id).orElse(null);
                
    }

    @Override
    @Transactional(readOnly=true)
    public List<CLiente> findByAll() {
        return (List<CLiente>) clienteDao.findAll();
    }
     
    
}
