
package com.sena.Inventario.Controller;

import com.sena.Inventario.Models_Clases.Venta;
import com.sena.Inventario.Service.VentaService;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/Venta")

public class VentaController {
    
    @Autowired
    private VentaService ventaservice;
    
    @PostMapping(value="/")
    public ResponseEntity<Venta> agregar(@RequestBody Venta venta){        
        Venta obj = ventaservice.save(venta);
        return new ResponseEntity<>(obj, HttpStatus.OK);     
    }

     @DeleteMapping(value="/{id}") 
    public ResponseEntity<Venta> eliminar(@PathVariable Integer id){ 
        Venta obj = ventaservice.findById(Integer.SIZE);
        if(obj!=null) 
            ventaservice.delete(Integer.SIZE);
        else 
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR); 
        return new ResponseEntity<>(obj, HttpStatus.OK); 
    }
 
    @PutMapping(value="/") 
    public ResponseEntity<Venta> editar(@RequestBody Venta venta){ 
        Venta obj = ventaservice.findById(venta.getCodVenta());
        if(obj!=null) {
            obj.setFechaVenta(venta.getFechaVenta());
            obj.setClienteVenta(venta.getClienteVenta());
            obj.setTotalVenta(venta.getTotalVenta());
            ventaservice.save(obj); 
        } 
        else 
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR); 
        return new ResponseEntity<>(obj, HttpStatus.OK); 
    }

    @GetMapping("/list")
    public List<Venta> consultarTodo(){
        return ventaservice.findByAll(); 
    }

    @GetMapping("/list/{id}") 
    public Venta consultaPorId(@PathVariable Integer id){ 
        return ventaservice.findById(Integer.SIZE);
    }
    

}

