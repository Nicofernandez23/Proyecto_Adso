
package com.sena.Inventario.Models_Clases;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

public class Producto implements Serializable {
    @Id
    @Column(name="CodProducto")
    private Integer CodProducto;
    @Column(name="NombreProducto")
    private String NombreProducto;
    @Column(name="DescripcionProducto")
    private String DescripcionProducto;
    @Column(name="PrecioProducto")
    private Double PrecioProducto;
    @Column(name="CantStockProducto")
    private Integer CantStockProducto;
    @Column(name="ProveedorProducto")
    private Double ProveedorProducto;
    @ManyToOne
    @JoinColumn (name="CodProveedor")
    private Proveedor CodProveedor ; //Foranea, se debe definir la tabla con la que se relaciona "Proveedor" y luego el campo

    public Producto() {
    }

    public Producto(Integer CodProducto, String NombreProducto, String DescripcionProducto, Double PrecioProducto, Integer CantStockProducto, Double ProveedorProducto, Proveedor CodProveedor) {
        this.CodProducto = CodProducto;
        this.NombreProducto = NombreProducto;
        this.DescripcionProducto = DescripcionProducto;
        this.PrecioProducto = PrecioProducto;
        this.CantStockProducto = CantStockProducto;
        this.ProveedorProducto = ProveedorProducto;
        this.CodProveedor = CodProveedor;
    }

    public Integer getCodProducto() {
        return CodProducto;
    }

    public void setCodProducto(Integer CodProducto) {
        this.CodProducto = CodProducto;
    }

    public String getNombreProducto() {
        return NombreProducto;
    }

    public void setNombreProducto(String NombreProducto) {
        this.NombreProducto = NombreProducto;
    }

    public String getDescripcionProducto() {
        return DescripcionProducto;
    }

    public void setDescripcionProducto(String DescripcionProducto) {
        this.DescripcionProducto = DescripcionProducto;
    }

    public Double getPrecioProducto() {
        return PrecioProducto;
    }

    public void setPrecioProducto(Double PrecioProducto) {
        this.PrecioProducto = PrecioProducto;
    }

    public Integer getCantStockProducto() {
        return CantStockProducto;
    }

    public void setCantStockProducto(Integer CantStockProducto) {
        this.CantStockProducto = CantStockProducto;
    }

    public Double getProveedorProducto() {
        return ProveedorProducto;
    }

    public void setProveedorProducto(Double ProveedorProducto) {
        this.ProveedorProducto = ProveedorProducto;
    }

    public Proveedor getCodProveedor() {
        return CodProveedor;
    }

    public void setCodProveedor(Proveedor CodProveedor) {
        this.CodProveedor = CodProveedor;
    }

    
}
