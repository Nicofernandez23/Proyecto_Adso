
package com.sena.Inventario.Dao;
import com.sena.Inventario.Models_Clases.CLiente;
import com.sena.Inventario.Service.Implement.CLienteImplement;
import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface CLienteDao extends CrudRepository<CLiente,Integer> {
    
    @Transactional(readOnly=true)  //True no modifica ningun campo de la bd, solo lectura.
    @Query(value="select * from CLiente where CodCliente=:CodC" ,nativeQuery=true)
    public List<CLiente> consulta_cliente(@Param("CodC") Integer CodC);

    public CLiente save(CLienteImplement aThis);
}
