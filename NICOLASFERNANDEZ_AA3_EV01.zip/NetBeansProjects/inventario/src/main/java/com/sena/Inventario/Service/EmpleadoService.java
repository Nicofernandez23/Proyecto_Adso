
package com.sena.Inventario.Service;
import com.sena.Inventario.Models_Clases.Empleado;
import java.util.List;

public interface EmpleadoService {
    public Empleado save(Empleado empleado);
    public void delete(Integer id);
    public Empleado findById(Integer id);
    public List<Empleado> findByAll();
    public Empleado login(Integer usuario, Integer clave);
    
}