
package com.sena.Inventario.Service.Implement;

import com.sena.Inventario.Models_Clases.Empleado;
import com.sena.Inventario.Dao.EmpleadoDao;
import com.sena.Inventario.Service.EmpleadoService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;
        
@Service 
public class EmpleadoImplement implements EmpleadoService {
        @Autowired
    private EmpleadoDao empleadoDao;

    @Override
    @Transactional(readOnly=false)
    public Empleado save(Empleado empleado) {
        return empleadoDao.save(empleado);         
    } 

    @Override
    @Transactional(readOnly=false)
    public void delete(Integer id) {
        empleadoDao.deleteById(id);
    }

    @Override
    @Transactional(readOnly=true)
    public Empleado findById(Integer id) {
        return empleadoDao.findById(id).orElse(null);
                
    }

    @Override
    @Transactional(readOnly=true)
    public List<Empleado> findByAll() {
        return (List<Empleado>) empleadoDao.findAll();
    }

    @Override
    public Empleado login(Integer usuario, Integer clave) {
        return empleadoDao.login(usuario, clave);
    }
    
}
