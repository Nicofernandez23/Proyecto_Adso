
package com.sena.Inventario.Controller;

import com.sena.Inventario.Models_Clases.Empleado;
import com.sena.Inventario.Service.EmpleadoService;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/Empleado")

public class EmpleadoController {
    @Autowired
    private EmpleadoService empleadoservice;
    
    @PostMapping(value="/")
    public ResponseEntity<Empleado> agregar(@RequestBody Empleado empleado){        
        Empleado obj = empleadoservice.save(empleado);
        return new ResponseEntity<>(obj, HttpStatus.OK);     
    }

     @DeleteMapping(value="/{id}") 
    public ResponseEntity<Empleado> eliminar(@PathVariable String id){ 
        Empleado obj = empleadoservice.findById(Integer.SIZE);
        if(obj!=null) 
            empleadoservice.delete(Integer.SIZE);
        else 
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR); 
        return new ResponseEntity<>(obj, HttpStatus.OK); 
    }
 
    @PutMapping(value="/") 
    public ResponseEntity<Empleado> editar(@RequestBody Empleado empleado){ 
        Empleado obj = empleadoservice.findById(empleado.getCodEmpleado());
        if(obj!=null) {
            obj.setNombreEmpleado(empleado.getNombreEmpleado());
            obj.setEdadEmpleado(empleado.getEdadEmpleado());
            obj.setSalarioEmpleado(empleado.getSalarioEmpleado());
            empleadoservice.save(obj); 
        } 
        else 
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR); 
        return new ResponseEntity<>(obj, HttpStatus.OK); 
    }

    @GetMapping("/list")
    public List<Empleado> consultarTodo(){
        return empleadoservice.findByAll(); 
    }

    @GetMapping("/list/{id}") 
    public Empleado consultaPorId(@PathVariable Integer id){ 
        return empleadoservice.findById(Integer.SIZE);
    }
    
    @GetMapping("/login") 
    public Empleado login(@RequestParam("usuario") String usuario,@RequestParam("clave") String clave){ 
        return empleadoservice.login(Integer.SIZE, Integer.SIZE);
    }

}
