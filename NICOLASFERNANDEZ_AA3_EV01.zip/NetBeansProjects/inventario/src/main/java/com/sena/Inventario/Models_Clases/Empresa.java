
package com.sena.Inventario.Models_Clases;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity(name="Empresa")
public class Empresa implements Serializable {
    @Id
    @Column(name="Cod_Empresa")
    private Integer Cod_Empresa;
    @Column(name="Nombre_Empresa")
    private String  Nombre_Empresa;

    public Empresa() {
    }

    public Empresa(Integer Cod_Empresa, String Nombre_Empresa) {
        this.Cod_Empresa = Cod_Empresa;
        this.Nombre_Empresa = Nombre_Empresa;
    }

    public Integer getCod_Empresa() {
        return Cod_Empresa;
    }

    public void setCod_Empresa(Integer Cod_Empresa) {
        this.Cod_Empresa = Cod_Empresa;
    }

    public String getNombre_Empresa() {
        return Nombre_Empresa;
    }

    public void setNombre_Empresa(String Nombre_Empresa) {
        this.Nombre_Empresa = Nombre_Empresa;
    }
            
}
