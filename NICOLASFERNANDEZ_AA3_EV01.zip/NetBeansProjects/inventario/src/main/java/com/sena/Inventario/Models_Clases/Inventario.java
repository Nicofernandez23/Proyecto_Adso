
package com.sena.Inventario.Models_Clases;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

public class Inventario implements Serializable {
    @Id
    @Column(name="CodInventario")
    private Integer CodInventario;
    @ManyToOne
    @JoinColumn (name="CodProducto")
    private Producto CodProducto; //Foranea, se debe definir la tabla con la que se relaciona "Producto" y luego el campo
    @Column(name="CantProducto")
    private Integer CantProducto;
    @Column(name="CantProducto")
    private String AlertasStock; 

    public Inventario() {
    }

    public Inventario(Integer CodInventario, Producto CodProducto, Integer CantProducto, String AlertasStock) {
        this.CodInventario = CodInventario;
        this.CodProducto = CodProducto;
        this.CantProducto = CantProducto;
        this.AlertasStock = AlertasStock;
    }

    public Integer getCodInventario() {
        return CodInventario;
    }

    public void setCodInventario(Integer CodInventario) {
        this.CodInventario = CodInventario;
    }

    public Producto getCodProducto() {
        return CodProducto;
    }

    public void setCodProducto(Producto CodProducto) {
        this.CodProducto = CodProducto;
    }

    public Integer getCantProducto() {
        return CantProducto;
    }

    public void setCantProducto(Integer CantProducto) {
        this.CantProducto = CantProducto;
    }

    public String getAlertasStock() {
        return AlertasStock;
    }

    public void setAlertasStock(String AlertasStock) {
        this.AlertasStock = AlertasStock;
    }


    
}
