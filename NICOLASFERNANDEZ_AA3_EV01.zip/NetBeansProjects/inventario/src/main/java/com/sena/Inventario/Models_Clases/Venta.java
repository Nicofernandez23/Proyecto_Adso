
package com.sena.Inventario.Models_Clases;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

public class Venta implements Serializable {
    @Id
    @Column(name="CodVenta")
    private Integer CodVenta;
    @Column(name="FechaVenta")
    private Datetime FechaVenta;
    @Column(name="TotalVenta")
    private Double TotalVenta;
    @Column(name="ClienteVenta")
    private String ClienteVenta;
    @ManyToOne
    @JoinColumn (name="CodEmpleado")
    private Empleado CodEmpleado;  //Foranea, se debe definir la tabla con la que se relaciona "Empleado" y luego el campo
    @ManyToOne
    @JoinColumn (name="CodCliente") 
    private CLiente CodCliente; //Foranea, se debe definir la tabla con la que se relaciona "Cliente" y luego el campo

    public Venta() {
    }

    public Venta(Integer CodVenta, Datetime FechaVenta, Double TotalVenta, String ClienteVenta, Empleado CodEmpleado, CLiente CodCliente) {
        this.CodVenta = CodVenta;
        this.FechaVenta = FechaVenta;
        this.TotalVenta = TotalVenta;
        this.ClienteVenta = ClienteVenta;
        this.CodEmpleado = CodEmpleado;
        this.CodCliente = CodCliente;
    }

    public Integer getCodVenta() {
        return CodVenta;
    }

    public void setCodVenta(Integer CodVenta) {
        this.CodVenta = CodVenta;
    }

    public Datetime getFechaVenta() {
        return FechaVenta;
    }

    public void setFechaVenta(Datetime FechaVenta) {
        this.FechaVenta = FechaVenta;
    }

    public Double getTotalVenta() {
        return TotalVenta;
    }

    public void setTotalVenta(Double TotalVenta) {
        this.TotalVenta = TotalVenta;
    }

    public String getClienteVenta() {
        return ClienteVenta;
    }

    public void setClienteVenta(String ClienteVenta) {
        this.ClienteVenta = ClienteVenta;
    }

    public Empleado getCodEmpleado() {
        return CodEmpleado;
    }

    public void setCodEmpleado(Empleado CodEmpleado) {
        this.CodEmpleado = CodEmpleado;
    }

    public CLiente getCodCliente() {
        return CodCliente;
    }

    public void setCodCliente(CLiente CodCliente) {
        this.CodCliente = CodCliente;
    }

    
    
}
