
package com.sena.Inventario.Models_Clases;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

public class Empleado implements Serializable {
    @Id
    @Column(name="CodEmpleado")
    private Integer CodEmpleado;
    @Column(name="NombreEmpleado")
    private String NombreEmpleado;
    @Column(name="EdadEmpleado")
    private Integer EdadEmpleado;
    @Column(name="SalarioEmpleado")
    private Double SalarioEmpleado;
    @ManyToOne
    @JoinColumn (name="CodPerfil")
    private Perfil CodPerfil; //Foranea, se debe definir la tabla con la que se relaciona "Perfil" y luego el campo
    @ManyToOne
    @JoinColumn (name="CodEmpresa")
    private Empresa CodEmpresa; //Foranea, se debe definir la tabla con la que se relaciona "Empresa" y luego el campo

    public Empleado() {
    }

    public Empleado(Integer CodEmpleado, String NombreEmpleado, Integer EdadEmpleado, Double SalarioEmpleado, Perfil CodPerfil, Empresa CodEmpresa) {
        this.CodEmpleado = CodEmpleado;
        this.NombreEmpleado = NombreEmpleado;
        this.EdadEmpleado = EdadEmpleado;
        this.SalarioEmpleado = SalarioEmpleado;
        this.CodPerfil = CodPerfil;
        this.CodEmpresa = CodEmpresa;
    }

    public Integer getCodEmpleado() {
        return CodEmpleado;
    }

    public void setCodEmpleado(Integer CodEmpleado) {
        this.CodEmpleado = CodEmpleado;
    }

    public String getNombreEmpleado() {
        return NombreEmpleado;
    }

    public void setNombreEmpleado(String NombreEmpleado) {
        this.NombreEmpleado = NombreEmpleado;
    }

    public Integer getEdadEmpleado() {
        return EdadEmpleado;
    }

    public void setEdadEmpleado(Integer EdadEmpleado) {
        this.EdadEmpleado = EdadEmpleado;
    }

    public Double getSalarioEmpleado() {
        return SalarioEmpleado;
    }

    public void setSalarioEmpleado(Double SalarioEmpleado) {
        this.SalarioEmpleado = SalarioEmpleado;
    }

    public Perfil getCodPerfil() {
        return CodPerfil;
    }

    public void setCodPerfil(Perfil CodPerfil) {
        this.CodPerfil = CodPerfil;
    }

    public Empresa getCodEmpresa() {
        return CodEmpresa;
    }

    public void setCodEmpresa(Empresa CodEmpresa) {
        this.CodEmpresa = CodEmpresa;
    }


}

