
package com.sena.Inventario.Models_Clases;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity(name="CLiente")
public class CLiente implements Serializable {
    @Id
    @Column(name="CodCliente")
    private Integer CodCliente;
    @Column(name="NombreCliente")
    private String NombreCliente;
    @Column(name="DireccionCliente")
    private String DireccionCliente;
    @Column(name="ContactoCliente")
    private String ContactoCliente;
    @Column(name="HistorialDeComprasCliente")
    private String HistorialDeComprasCliente;

    public CLiente() {
    }

    public CLiente(Integer CodCliente, String NombreCliente, String DireccionCliente, String ContactoCliente, String HistorialDeComprasCliente) {
        this.CodCliente = CodCliente;
        this.NombreCliente = NombreCliente;
        this.DireccionCliente = DireccionCliente;
        this.ContactoCliente = ContactoCliente;
        this.HistorialDeComprasCliente = HistorialDeComprasCliente;
    }

    public Integer getCodCliente() {
        return CodCliente;
    }

    public void setCodCliente(Integer CodCliente) {
        this.CodCliente = CodCliente;
    }

    public String getNombreCliente() {
        return NombreCliente;
    }

    public void setNombreCliente(String NombreCliente) {
        this.NombreCliente = NombreCliente;
    }

    public String getDireccionCliente() {
        return DireccionCliente;
    }

    public void setDireccionCliente(String DireccionCliente) {
        this.DireccionCliente = DireccionCliente;
    }

    public String getContactoCliente() {
        return ContactoCliente;
    }

    public void setContactoCliente(String ContactoCliente) {
        this.ContactoCliente = ContactoCliente;
    }

    public String getHistorialDeComprasCliente() {
        return HistorialDeComprasCliente;
    }

    public void setHistorialDeComprasCliente(String HistorialDeComprasCliente) {
        this.HistorialDeComprasCliente = HistorialDeComprasCliente;
    }
    
    
}
