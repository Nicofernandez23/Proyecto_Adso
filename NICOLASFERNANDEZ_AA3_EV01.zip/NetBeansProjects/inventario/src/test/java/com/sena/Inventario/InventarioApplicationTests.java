package com.sena.Inventario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
