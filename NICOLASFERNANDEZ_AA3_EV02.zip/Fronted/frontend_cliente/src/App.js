import logo from './logo.svg';
import './App.css';
import Login from './componentes/Login';
import Menu from './componentes/Menu';
import Logout from './componentes/Logout';
import Operaciones from './componentes/Operaciones';
import RealizarVenta from './componentes/Venta';
import Inicio from './componentes/Inicio';
import RegistrarCliente from './componentes/CLiente';

import {BrowserRouter, Route, Routes} from "react-router-dom"

function App() {
  return (
    <div className="App">
      <div className='App-header'>
        <Menu/>

        <BrowserRouter>
<Routes>
<Route path="/" element={<Login />} />
<Route path="/login" element={<Login />} />
<Route path="/inicio" element={<Inicio />} />
<Route path="/logout" element={<Logout />} />
<Route path="/Operaciones" element={<Operaciones />} />
<Route path="/vender" element={<RealizarVenta />} />
<Route path="/CLiente" element={<RegistrarCliente />} />



</Routes>
</BrowserRouter>

     </div>
    </div>
  );
}

export default App;
