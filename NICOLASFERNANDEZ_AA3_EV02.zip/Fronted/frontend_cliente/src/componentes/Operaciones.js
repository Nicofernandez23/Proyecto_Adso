import swal from "sweetalert";
import axios from "axios";
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

// URI para el consumo de la API
const URI = "http://localhost:8080/inventario/";

// Quemando las credenciales (usuario1, pass 123)
const headers = {
  usuario: "1", // Usuario predefinido
  clave: "123", // Contraseña predefinida
};

const Operaciones = () => {
  const navigate = useNavigate();
  const [productos, setProductos] = useState([]);

  useEffect(() => {
    // Simulación de obtener productos (quemado)
    const fakeProductos = [
      { id_articulo: "101", articulo: "Jean T10", cantidad: 20, proveedor: "Big Jhon" },
      { id_articulo: "102", articulo: "Blusa TS", cantidad: 15, proveedor: "Studio F" },
      { id_articulo: "103", articulo: "Chaqueta TU", cantidad: 5, proveedor: "Nike" },
    ];

    setProductos(fakeProductos);
  }, []);

  return (
    <div className="container">
      <div className="row">
        <div className="col">
          <table className="table">
            <thead className="table-primary">
              <tr>
                <th>Artículo</th>
                <th>Cantidad</th>
                <th>Proveedor</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {productos.map((producto) => (
                <tr key={producto.id_articulo}>
                  <td>{producto.articulo}</td>
                  <td>{producto.cantidad}</td>
                  <td>{producto.proveedor}</td>
                  <td>
                    <Link
                      to={`/detalles-producto/${producto.id_articulo}`}
                      className="btn btn-info"
                    >
                      <i className="fas fa-info-circle"></i> Detalles
                    </Link>
                    <Link
                      to={`/editar-producto/${producto.id_articulo}`}
                      className="btn btn-warning"
                    >
                      <i className="fas fa-edit"></i> Editar
                    </Link>
                    <button
                      className="btn btn-danger"
                      onClick={() => {
                        swal({
                          title: "¿Estás seguro?",
                          text: "Una vez eliminada, no podrás recuperar este producto.",
                          icon: "warning",
                          buttons: true,
                          dangerMode: true,
                        }).then((willDelete) => {
                          if (willDelete) {
                            setProductos(
                              productos.filter((p) => p.id_articulo !== producto.id_articulo)
                            );
                            swal("El producto ha sido eliminado", {
                              icon: "success",
                            });
                          }
                        });
                      }}
                    >
                      <i className="fas fa-trash"></i> Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Operaciones;
