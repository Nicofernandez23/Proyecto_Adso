import React from "react";
import { Link } from "react-router-dom";

const Inicio = () => {
  return (
    <div className="container">
      <div className="row">
        <div className="col-12 text-center">
          <h2>Bienvenido al Sistema de Inventario</h2>
          <p>Seleccione una opción para continuar</p>
        </div>
      </div>

      <div className="row mt-4">
        {/* Opción Registrar Inventario */}
        <div className="col-md-4">
          <div className="card">
            <div className="card-body text-center">
              <h5 className="card-title">Registrar Inventario</h5>
              <p className="card-text">Añade nuevos productos al inventario.</p>
              <Link to="/Operaciones" className="btn btn-primary">
                Registrar Producto
              </Link>
            </div>
          </div>
        </div>

        {/* Opción Vender */}
        <div className="col-md-4">
          <div className="card">
            <div className="card-body text-center">
              <h5 className="card-title">Vender</h5>
              <p className="card-text">Realiza ventas y controla el inventario.</p>
              <Link to="/vender" className="btn btn-success">
                Realizar Venta
              </Link>
            </div>
          </div>
        </div>

        {/* Opción Cliente */}
        <div className="col-md-4">
          <div className="card">
            <div className="card-body text-center">
              <h5 className="card-title">Registrar cliente</h5>
              <p className="card-text">Registrar y consultar clientes.</p>
              <Link to="/CLiente" className="btn btn-info">
                Registrar Cliente
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="row mt-4">
        {/* Opción Control de Inventario */}
        <div className="col-md-4">
          <div className="card">
            <div className="card-body text-center">
              <h5 className="card-title">Control de Inventario</h5>
              <p className="card-text">Visualiza y gestiona el inventario actual.</p>
              <Link to="/control-inventario" className="btn btn-warning">
                Ver Inventario
              </Link>
            </div>
          </div>
        </div>

        {/* Opción Reportes */}
        <div className="col-md-4">
          <div className="card">
            <div className="card-body text-center">
              <h5 className="card-title">Indicadores de Ventas</h5>
              <p className="card-text">Consulta los indicadores y estadísticas de ventas.</p>
              <Link to="/reportes" className="btn btn-danger">
                Ver Reportes
              </Link>
            </div>
          </div>
        </div>

        {/* Opción Configuración */}
        <div className="col-md-4">
          <div className="card">
            <div className="card-body text-center">
              <h5 className="card-title">Configuración</h5>
              <p className="card-text">Ajusta las configuraciones del sistema.</p>
              <Link to="/configuracion" className="btn btn-secondary">
                Configuración
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Inicio;