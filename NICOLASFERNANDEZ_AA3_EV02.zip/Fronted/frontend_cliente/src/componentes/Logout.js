import swal from "sweetalert";
import { useNavigate } from "react-router-dom";
const Logout = () => {
    sessionStorage.removeItem("usuario")
    sessionStorage.removeItem("clave")
    const navigate = useNavigate();
    swal("Sesión Finalizada!", "Presiona el botón!", "success");
    navigate("/");

    return(
        <div className='container'>
        <br>
        </br>
        <p>¡Hasta Pronto!</p>
        </div>
        )

    };
    export default Logout;