import swal from "sweetalert";
import axios from "axios";
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import React from "react";

const RealizarVenta = () => {
    const handleConfirmarVenta = () => {
      // Muestra una alerta con sweetalert
      swal("¡Venta Realizada con Éxito!", "Por favor, confirma los datos registrados", "success");
      // Aquí podrías agregar lógica adicional, como redireccionar a otra página o registrar la venta en la base de datos
    };
  
    return (
      <div className="container mt-5">
        <div className="card">
          <div className="card-header text-center bg-success text-white">
            <h3>Realizar Venta</h3>
          </div>
          <div className="card-body">
            <h5>Datos Generales</h5>
            <ul className="list-group">
              <li className="list-group-item">
                <strong>Cliente:</strong> Andrea Ramirez
              </li>
              <li className="list-group-item">
                <strong>Cédula:</strong> 1004680139
              </li>
              <li className="list-group-item">
                <strong>Artículo:</strong> (1) Jean T10
              </li>
              <li className="list-group-item">
                <strong>Valor:</strong> $90.000
              </li>
              <li className="list-group-item">
                <strong>Vendedor:</strong> Nicolas Fernandez
              </li>
            </ul>
            <div className="text-center mt-4">
              <button
                className="btn btn-primary"
                onClick={handleConfirmarVenta} // Llama a la función al hacer clic
              >
                Confirmar Venta
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  export default RealizarVenta;