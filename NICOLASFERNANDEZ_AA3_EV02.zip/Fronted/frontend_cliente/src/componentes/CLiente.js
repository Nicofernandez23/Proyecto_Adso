import React, { useState } from "react";
import swal from "sweetalert";

const RegistrarCliente = () => {
  const [formData, setFormData] = useState({
    CodCliente: "",
    NombreCliente: "",
    DireccionCliente: "",
    ContactoCliente: "",
    EmailCliente: "",
  });

  const [clienteRegistrado, setClienteRegistrado] = useState(null);
  const [codigoConsulta, setCodigoConsulta] = useState("");
  const [clienteEncontrado, setClienteEncontrado] = useState(null);

  // Datos quemados para consulta
  const clientesSimulados = [
    { CodCliente: 1, NombreCliente: "Nicolas Fernandez", DireccionCliente: "Kra20_28", ContactoCliente: "3222686819", EmailCliente: "nicolas@gmail.com" },
    { CodCliente: 2, NombreCliente: "Andrea Ramirez", DireccionCliente: "Kra80_78", ContactoCliente: "3217249099", EmailCliente: "andrea@gmail.com" },
    { CodCliente: 3, NombreCliente: "Jacobo Fernandez", DireccionCliente: "Kra34_78", ContactoCliente: "3217249099", EmailCliente: "jacobo@gmail.com" },
    { CodCliente: 4, NombreCliente: "Matias Fernandez", DireccionCliente: "Kra34_78", ContactoCliente: "3219349502", EmailCliente: "matias@gmail.com" },
    { CodCliente: 5, NombreCliente: "Yina Martinez", DireccionCliente: "Kra18_17_75", ContactoCliente: "3164130593", EmailCliente: "yina@gmail.com" },
    { CodCliente: 6, NombreCliente: "Steven Jimenez", DireccionCliente: "Spain", ContactoCliente: "+343456532", EmailCliente: "steven@gmail.com" },
    { CodCliente: 7, NombreCliente: "James Marin", DireccionCliente: "Kra26_38", ContactoCliente: "3019274583", EmailCliente: "james@gmail.com" },
  ];

  // Manejar los cambios en los inputs del formulario de registro
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Manejar el envío del formulario de registro
  const handleSubmit = (e) => {
    e.preventDefault();

    // Simular el registro del cliente
    setClienteRegistrado(formData);

    // Mostrar alerta de éxito
    swal("¡Registro Exitoso!", "El cliente ha sido registrado correctamente.", "success");

    // Limpiar el formulario
    setFormData({
      CodCliente: "",
      NombreCliente: "",
      DireccionCliente: "",
      ContactoCliente: "",
      EmailCliente: "",
    });
  };

  // Manejar la consulta de cliente
  const handleConsulta = (e) => {
    e.preventDefault();

    // Buscar cliente en los datos quemados
    const cliente = clientesSimulados.find((c) => c.CodCliente === parseInt(codigoConsulta));
    if (cliente) {
      setClienteEncontrado(cliente);
    } else {
      swal("Cliente no encontrado", "No se encontró un cliente con ese código.", "error");
      setClienteEncontrado(null);
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center">Registrar Cliente</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="CodCliente" className="form-label">
            Código del Cliente
          </label>
          <input
            type="number"
            className="form-control"
            id="CodCliente"
            name="CodCliente"
            value={formData.CodCliente}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="NombreCliente" className="form-label">
            Nombre del Cliente
          </label>
          <input
            type="text"
            className="form-control"
            id="NombreCliente"
            name="NombreCliente"
            value={formData.NombreCliente}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="DireccionCliente" className="form-label">
            Dirección
          </label>
          <input
            type="text"
            className="form-control"
            id="DireccionCliente"
            name="DireccionCliente"
            value={formData.DireccionCliente}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="ContactoCliente" className="form-label">
            Contacto
          </label>
          <input
            type="text"
            className="form-control"
            id="ContactoCliente"
            name="ContactoCliente"
            value={formData.ContactoCliente}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="EmailCliente" className="form-label">
            Correo Electrónico
          </label>
          <input
            type="email"
            className="form-control"
            id="EmailCliente"
            name="EmailCliente"
            value={formData.EmailCliente}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Registrar Cliente
        </button>
      </form>

      {/* Mostrar los datos del cliente registrado */}
      {clienteRegistrado && (
        <div className="alert alert-success mt-4">
          <h4>Cliente Registrado:</h4>
          <p><strong>Código:</strong> {clienteRegistrado.CodCliente}</p>
          <p><strong>Nombre:</strong> {clienteRegistrado.NombreCliente}</p>
          <p><strong>Dirección:</strong> {clienteRegistrado.DireccionCliente}</p>
          <p><strong>Contacto:</strong> {clienteRegistrado.ContactoCliente}</p>
          <p><strong>Email:</strong> {clienteRegistrado.EmailCliente}</p>
        </div>
      )}

      <hr className="my-5" />

      {/* Sección de consulta de cliente */}
      <h2 className="text-center">Consultar Cliente</h2>
      <form onSubmit={handleConsulta}>
        <div className="mb-3">
          <label htmlFor="codigoConsulta" className="form-label">
            Código del Cliente
          </label>
          <input
            type="number"
            className="form-control"
            id="codigoConsulta"
            value={codigoConsulta}
            onChange={(e) => setCodigoConsulta(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-info">
          Consultar Cliente
        </button>
      </form>

      {/* Mostrar los datos del cliente consultado */}
      {clienteEncontrado && (
        <div className="card mt-4">
          <div className="card-body">
            <h4 className="card-title">Cliente Encontrado:</h4>
            <p><strong>Código:</strong> {clienteEncontrado.CodCliente}</p>
            <p><strong>Nombre:</strong> {clienteEncontrado.NombreCliente}</p>
            <p><strong>Dirección:</strong> {clienteEncontrado.DireccionCliente}</p>
            <p><strong>Contacto:</strong> {clienteEncontrado.ContactoCliente}</p>
            <p><strong>Email:</strong> {clienteEncontrado.EmailCliente}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default RegistrarCliente;