import React, { useState, useEffect } from "react";
import './Menu.css'; // Importa el archivo de estilos

const Menu = () => {
    const [fechaHora, setFechaHora] = useState("");

    useEffect(() => {
        const intervalo = setInterval(() => {
            const ahora = new Date();
            const fechaFormateada = ahora.toLocaleDateString(); // Formato de fecha
            const horaFormateada = ahora.toLocaleTimeString(); // Formato de hora
            setFechaHora(`${fechaFormateada} ${horaFormateada}`);
        }, 1000); // Actualizar cada segundo

        return () => clearInterval(intervalo); // Limpiar el intervalo al desmontar
    }, []);

    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
            <div className="container-fluid">
                <a className="navbar-brand" href="/login">
                    InventarioApp
                </a>
                <div className="collapse navbar-collapse">
                    <ul className="navbar-nav mx-auto mb-2 mb-lg-0">
                        <li className="nav-item">
                            <a className="nav-link active" aria-current="page" href="/login">
                                Login
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link active" aria-current="page" href="/Inicio">
                                Inicio
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link active" aria-current="page" href="/operaciones">
                                Operaciones
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="/logout">
                                LogOut
                            </a>
                        </li>
                    </ul>
                </div>
                <span className="navbar-text text-white">
                    {fechaHora}
                </span>
            </div>
        </nav>
    );
};

export default Menu;