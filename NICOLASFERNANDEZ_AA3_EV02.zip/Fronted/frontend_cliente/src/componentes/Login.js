import swal from "sweetalert";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Login = () => {
    const navigate = useNavigate();
    const [id_cliente, setId_cliente] = useState("");
    const [clave_cliente, setClave_cliente] = useState("");

    const guardar = (e) => {
        e.preventDefault();

        // Validación de usuario quemado
        if (id_cliente === "1" && clave_cliente === "123") {
            sessionStorage.setItem("usuario", id_cliente);
            sessionStorage.setItem("clave", clave_cliente);
            swal("Bienvenido Usuario Nicolas Fernandez!", "Presiona el botón!", "success");
            navigate("/Inicio");
        } else {
            swal("Usuario o clave incorrecta", "Intenta nuevamente", "error");
        }
    };

    return (
        <div className="d-flex justify-content-center align-items-center vh-100">
            <div className="card shadow" style={{ width: "400px" }}>
                <div className="card-header bg-primary text-white text-center">
                    <h4>Inicio de Sesión</h4>
                </div>
                <div className="card-body">
                    <form onSubmit={guardar}>
                        <div className="mb-3">
                            <label className="form-label">Usuario</label>
                            <input
                                value={id_cliente}
                                onChange={(e) => setId_cliente(e.target.value)}
                                type="text"
                                maxLength={15}
                                required
                                placeholder="Ingresa tu usuario"
                                className="form-control"
                            />
                        </div>

                        <div className="mb-3">
                            <label className="form-label">Contraseña</label>
                            <input
                                value={clave_cliente}
                                onChange={(e) => setClave_cliente(e.target.value)}
                                type="password"
                                maxLength={50}
                                required
                                placeholder="Ingresa tu contraseña"
                                className="form-control"
                            />
                        </div>

                        <button type="submit" className="btn btn-primary w-100">
                            Iniciar Sesión
                        </button>
                    </form>
                </div>
                <div className="card-footer text-center text-muted">
                    <small>© InventarioApp 2024</small>
                </div>
            </div>
        </div>
    );
};

export default Login;